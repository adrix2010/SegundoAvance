/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


function validaGasto(){
    var nombre = document.getElementById('nombreG').value;
    var servicio = document.getElementById('servicio').value;
    var presta = document.getElementById('prestador').value;
    var cantidad = document.getElementById('cantidadInv').value;
    var fecha = document.getElementById('fechaG').value;
    
    
     if(nombre==""){
         alert('Ingresa el nombre del gasto');
         document.getElementById("nombreG").focus();
         document.getElementById('Ingresargasto').disable = true;
         valido= false;
     } else{
         if(servicio==""){
         alert('Ingresa el concepto del gasto correctamente');
         document.getElementById("servicio").focus();
         document.getElementById('Ingresargasto').disable = true;
         valido= false;             
         } else{
         if(presta==""){
                  
         alert('Ingresa el prestador con quien se efectuo el gasto correctamente');
         document.getElementById("Prestador").focus();
         document.getElementById('Ingresargasto').disable = true;
         valido= false;             
         }else{
            if(fecha==""){
            alert('Ingresa una fechaválida');
            document.getElementById("cantidadInv").focus();
            document.getElementById('Ingresargasto').disable = true;
            valido= false; 
         } else{
             if(cantidad==""){
                 alert('Ingresa una cantidad válida');
                 document.getElementById("cantidadInv").focus();
                 document.getElementById('Ingresargasto').disable = true;
                 valido= false; 
             }else{
                 valido == true;
                   alert('Datos correctos, registrando...');
          document.forms[0].submit();
                }
             }
         }
            }
         }
 
}
     
    
    
    
            
     
     function SoloNumeros(e)
{
    var key = window.Event ? e.which : e.keyCode
	return (key >= 48 && key <= 57 || key == 46)
    {
		alert('Solo puede contener números');
		return false;
    }
}

function SoloLetras(e)
{
    var key = window.Event ? e.which : e.keyCode
	return ((key >= 65 && key <= 90) || (key >= 97 && key <=122) || (key >= 97 && key <=122) || (key >= 128 && key <=141)  )
    {
		alert('Solo puede contener letras');
		return false;
    }
}


        
      
        
